import json

def function(params):
    params = json.loads(params)
    sum = params["sum"]
    
    resp = "Positive, sum is: " + str(sum)
    
    return resp