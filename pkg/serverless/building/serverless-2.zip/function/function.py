import json

def function(params):
    params = json.loads(params)
    sum = params["sum"]
    
    resp = "Negative, sum is: " + str(sum)
    
    return resp