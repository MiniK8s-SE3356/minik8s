import json

def function(params):
    params = json.loads(params)
    sum = params["sum"]
    resp = 0
    if sum > 0 :
        resp = 0
    elif sum == 0:
        resp = 1
    else:
        resp = 2
        
    return str(resp)